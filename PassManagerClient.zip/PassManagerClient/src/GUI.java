/*
Δημητρης Παναϊλιδης icsd11116
Νελλη Τσοτσου icsd11169
Γιωργος Βλασσοπουλος icsd11018
*/


import java.io.FileNotFoundException;
import java.io.IOException;
import java.net.MalformedURLException;
import java.rmi.NotBoundException;
import java.rmi.RemoteException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.swing.JOptionPane;

public class GUI extends javax.swing.JFrame {
   
    PassClient client;
    
    public GUI() {
        initComponents();
        PanelGUI.removeAll();
        PanelGUI.repaint();
        PanelGUI.revalidate();

        PanelGUI.add(Panel1);
        PanelGUI.repaint();
        PanelGUI.revalidate();
       
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        PanelGUI = new javax.swing.JPanel();
        Panel1 = new javax.swing.JPanel();
        PassManagerLabel = new javax.swing.JLabel();
        UserNameField = new java.awt.TextField();
        jSeparator = new javax.swing.JSeparator();
        ImageLabel = new javax.swing.JLabel();
        UserNameLabel = new javax.swing.JLabel();
        RegisterButton = new javax.swing.JButton();
        SignInButton = new javax.swing.JButton();
        Panel2 = new javax.swing.JPanel();
        AddPassLabel = new javax.swing.JLabel();
        ServiceNameLabel1 = new javax.swing.JLabel();
        ServiceNameTextField2 = new java.awt.TextField();
        PasswdLabel1 = new javax.swing.JLabel();
        GetPassLabel = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        ServiceNameLabel2 = new javax.swing.JLabel();
        ServiceNameTextField1 = new java.awt.TextField();
        SetPassButton = new javax.swing.JButton();
        GetPassButton = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        ChangePassLabel = new javax.swing.JLabel();
        ServiceNameLabel3 = new javax.swing.JLabel();
        ServiceNameTextField3 = new java.awt.TextField();
        NewPasswdLabel = new javax.swing.JLabel();
        ChangePassButton = new javax.swing.JButton();
        DeletePassLabel = new javax.swing.JLabel();
        ServiceNameLabel4 = new javax.swing.JLabel();
        ServiceNameTextField4 = new java.awt.TextField();
        DeletePassButton = new javax.swing.JButton();
        DeleteAccountLabel = new javax.swing.JLabel();
        UserNameLabel1 = new javax.swing.JLabel();
        UserNameTextField = new java.awt.TextField();
        DeleteAccountButton = new javax.swing.JButton();
        CheckSQLInjectionLabel = new javax.swing.JLabel();
        CheckSQLInjectionButton = new javax.swing.JButton();
        AddPassField = new javax.swing.JPasswordField();
        jPasswordField2 = new javax.swing.JPasswordField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        jSeparator3 = new javax.swing.JSeparator();
        jSeparator4 = new javax.swing.JSeparator();
        jSeparator6 = new javax.swing.JSeparator();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        Panel1.setBackground(new java.awt.Color(51, 51, 51));
        Panel1.setPreferredSize(new java.awt.Dimension(714, 425));

        PassManagerLabel.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        PassManagerLabel.setForeground(new java.awt.Color(204, 204, 204));
        PassManagerLabel.setText("Password Manager Service");

        UserNameField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserNameFieldUserNameFieldActionPerformed(evt);
            }
        });

        jSeparator.setForeground(new java.awt.Color(0, 0, 0));

        ImageLabel.setBackground(new java.awt.Color(51, 51, 51));
        ImageLabel.setIcon(new javax.swing.ImageIcon(getClass().getResource("/credentialrepository_trans.png"))); // NOI18N

        UserNameLabel.setFont(new java.awt.Font("Tahoma", 1, 14)); // NOI18N
        UserNameLabel.setForeground(new java.awt.Color(153, 153, 153));
        UserNameLabel.setText("UserName:");

        RegisterButton.setBackground(new java.awt.Color(0, 0, 0));
        RegisterButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        RegisterButton.setForeground(new java.awt.Color(51, 153, 255));
        RegisterButton.setText("Register");
        RegisterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                RegisterButtonRegisterButtonActionPerformed(evt);
            }
        });

        SignInButton.setBackground(new java.awt.Color(0, 0, 0));
        SignInButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        SignInButton.setForeground(new java.awt.Color(51, 153, 255));
        SignInButton.setText("Sign-in");
        SignInButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SignInButtonActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout Panel1Layout = new javax.swing.GroupLayout(Panel1);
        Panel1.setLayout(Panel1Layout);
        Panel1Layout.setHorizontalGroup(
            Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel1Layout.createSequentialGroup()
                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel1Layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(ImageLabel)
                        .addGap(26, 26, 26)
                        .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(UserNameField, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(UserNameLabel)
                            .addComponent(RegisterButton, javax.swing.GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE)
                            .addComponent(SignInButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addGroup(Panel1Layout.createSequentialGroup()
                        .addGap(197, 197, 197)
                        .addComponent(PassManagerLabel)))
                .addContainerGap(86, Short.MAX_VALUE))
            .addComponent(jSeparator, javax.swing.GroupLayout.Alignment.TRAILING)
        );
        Panel1Layout.setVerticalGroup(
            Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel1Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addComponent(PassManagerLabel)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(20, 20, 20)
                .addGroup(Panel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel1Layout.createSequentialGroup()
                        .addGap(106, 106, 106)
                        .addComponent(UserNameLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(UserNameField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36)
                        .addComponent(RegisterButton)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(SignInButton)
                        .addContainerGap())
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 39, Short.MAX_VALUE)
                        .addComponent(ImageLabel))))
        );

        Panel2.setBackground(new java.awt.Color(51, 51, 51));
        Panel2.setPreferredSize(new java.awt.Dimension(714, 425));

        AddPassLabel.setBackground(new java.awt.Color(204, 204, 204));
        AddPassLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        AddPassLabel.setForeground(new java.awt.Color(255, 255, 255));
        AddPassLabel.setText("Προσθήκη κωδικού για μια υπηρεσία");

        ServiceNameLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ServiceNameLabel1.setForeground(new java.awt.Color(153, 153, 153));
        ServiceNameLabel1.setText("Όνομα υπηρεσίας: ");

        ServiceNameTextField2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ServiceNameTextField2ActionPerformed(evt);
            }
        });

        PasswdLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        PasswdLabel1.setForeground(new java.awt.Color(153, 153, 153));
        PasswdLabel1.setText("Κωδικός: ");

        GetPassLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        GetPassLabel.setForeground(new java.awt.Color(255, 255, 255));
        GetPassLabel.setText("Ανάκτηση κωδικού υπηρεσίας ");

        ServiceNameLabel2.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ServiceNameLabel2.setForeground(new java.awt.Color(153, 153, 153));
        ServiceNameLabel2.setText("Όνομα υπηρεσίας: ");

        ServiceNameTextField1.setCursor(new java.awt.Cursor(java.awt.Cursor.TEXT_CURSOR));
        ServiceNameTextField1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ServiceNameTextField1ActionPerformed(evt);
            }
        });

        SetPassButton.setBackground(new java.awt.Color(0, 0, 0));
        SetPassButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        SetPassButton.setForeground(new java.awt.Color(51, 153, 255));
        SetPassButton.setText("Προσθήκη");
        SetPassButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                SetPassButtonActionPerformed(evt);
            }
        });

        GetPassButton.setBackground(new java.awt.Color(0, 0, 0));
        GetPassButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        GetPassButton.setForeground(new java.awt.Color(51, 153, 255));
        GetPassButton.setText("Ανάκτηση");
        GetPassButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                GetPassButtonActionPerformed(evt);
            }
        });

        ChangePassLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        ChangePassLabel.setForeground(new java.awt.Color(255, 255, 255));
        ChangePassLabel.setText("Αλλαγή κωδικού υπηρεσίας");

        ServiceNameLabel3.setBackground(new java.awt.Color(153, 153, 153));
        ServiceNameLabel3.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ServiceNameLabel3.setForeground(new java.awt.Color(153, 153, 153));
        ServiceNameLabel3.setText("Όνομα υπηρεσίας: ");

        ServiceNameTextField3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ServiceNameTextField3ActionPerformed(evt);
            }
        });

        NewPasswdLabel.setBackground(new java.awt.Color(153, 153, 153));
        NewPasswdLabel.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        NewPasswdLabel.setForeground(new java.awt.Color(153, 153, 153));
        NewPasswdLabel.setText("Νέος κωδικός: ");

        ChangePassButton.setBackground(new java.awt.Color(0, 0, 0));
        ChangePassButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        ChangePassButton.setForeground(new java.awt.Color(51, 153, 255));
        ChangePassButton.setText("Αλλαγή");
        ChangePassButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ChangePassButtonActionPerformed(evt);
            }
        });

        DeletePassLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        DeletePassLabel.setForeground(new java.awt.Color(255, 255, 255));
        DeletePassLabel.setText("Διαγραφή κωδικού υπηρεσίας ");

        ServiceNameLabel4.setBackground(new java.awt.Color(153, 153, 153));
        ServiceNameLabel4.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        ServiceNameLabel4.setForeground(new java.awt.Color(153, 153, 153));
        ServiceNameLabel4.setText("Όνομα υπηρεσίας: ");

        ServiceNameTextField4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ServiceNameTextField4ActionPerformed(evt);
            }
        });

        DeletePassButton.setBackground(new java.awt.Color(0, 0, 0));
        DeletePassButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        DeletePassButton.setForeground(new java.awt.Color(51, 153, 255));
        DeletePassButton.setText("Διαγραφή");
        DeletePassButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeletePassButtonActionPerformed(evt);
            }
        });

        DeleteAccountLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        DeleteAccountLabel.setForeground(new java.awt.Color(255, 255, 255));
        DeleteAccountLabel.setText("Διαγραφή λογαριασμού");

        UserNameLabel1.setFont(new java.awt.Font("Tahoma", 1, 11)); // NOI18N
        UserNameLabel1.setForeground(new java.awt.Color(153, 153, 153));
        UserNameLabel1.setText("Όνομα χρήστη: ");

        UserNameTextField.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                UserNameTextFieldActionPerformed(evt);
            }
        });

        DeleteAccountButton.setBackground(new java.awt.Color(0, 0, 0));
        DeleteAccountButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        DeleteAccountButton.setForeground(new java.awt.Color(51, 153, 255));
        DeleteAccountButton.setText("Διαγραφή");
        DeleteAccountButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                DeleteAccountButtonActionPerformed(evt);
            }
        });

        CheckSQLInjectionLabel.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        CheckSQLInjectionLabel.setForeground(new java.awt.Color(255, 255, 255));
        CheckSQLInjectionLabel.setText("Έλεγχο για προσβολή της ακεραιότητας του κωδικού της υπηρεσίας από τον εξυπηρετητή");

        CheckSQLInjectionButton.setBackground(new java.awt.Color(0, 0, 0));
        CheckSQLInjectionButton.setFont(new java.awt.Font("Tahoma", 1, 12)); // NOI18N
        CheckSQLInjectionButton.setForeground(new java.awt.Color(51, 153, 255));
        CheckSQLInjectionButton.setText("Έλεγχος");
        CheckSQLInjectionButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                CheckSQLInjectionButtonActionPerformed(evt);
            }
        });

        jSeparator1.setForeground(new java.awt.Color(255, 255, 255));

        jSeparator2.setForeground(new java.awt.Color(255, 255, 255));

        jSeparator3.setForeground(new java.awt.Color(255, 255, 255));

        jSeparator4.setForeground(new java.awt.Color(255, 255, 255));

        jSeparator6.setForeground(new java.awt.Color(255, 255, 255));

        javax.swing.GroupLayout Panel2Layout = new javax.swing.GroupLayout(Panel2);
        Panel2.setLayout(Panel2Layout);
        Panel2Layout.setHorizontalGroup(
            Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addComponent(AddPassLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addComponent(DeleteAccountLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator6))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel2Layout.createSequentialGroup()
                        .addGap(0, 10, Short.MAX_VALUE)
                        .addComponent(DeletePassLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 188, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 512, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGap(172, 172, 172)
                        .addComponent(jSeparator3))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addComponent(CheckSQLInjectionLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(CheckSQLInjectionButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addContainerGap())
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(Panel2Layout.createSequentialGroup()
                                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addGroup(Panel2Layout.createSequentialGroup()
                                        .addComponent(UserNameLabel1)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                        .addComponent(UserNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(Panel2Layout.createSequentialGroup()
                                            .addComponent(ServiceNameLabel1)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(ServiceNameTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(Panel2Layout.createSequentialGroup()
                                            .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                .addComponent(jLabel1)
                                                .addComponent(ServiceNameLabel2))
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(ServiceNameTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(Panel2Layout.createSequentialGroup()
                                            .addComponent(ServiceNameLabel3)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(ServiceNameTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(Panel2Layout.createSequentialGroup()
                                            .addComponent(ServiceNameLabel4)
                                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                            .addComponent(ServiceNameTextField4, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(Panel2Layout.createSequentialGroup()
                                        .addGap(24, 24, 24)
                                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                            .addGroup(Panel2Layout.createSequentialGroup()
                                                .addComponent(NewPasswdLabel)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(ChangePassButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(Panel2Layout.createSequentialGroup()
                                                .addGap(1, 1, 1)
                                                .addComponent(DeletePassButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(Panel2Layout.createSequentialGroup()
                                                .addGap(2, 2, 2)
                                                .addComponent(DeleteAccountButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))
                                            .addGroup(Panel2Layout.createSequentialGroup()
                                                .addComponent(PasswdLabel1)
                                                .addGap(31, 31, 31)
                                                .addComponent(AddPassField, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(SetPassButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                                    .addGroup(Panel2Layout.createSequentialGroup()
                                        .addGap(23, 23, 23)
                                        .addComponent(GetPassButton, javax.swing.GroupLayout.PREFERRED_SIZE, 100, javax.swing.GroupLayout.PREFERRED_SIZE))))
                            .addComponent(ChangePassLabel)
                            .addComponent(jLabel2))
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addComponent(GetPassLabel)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator2))))
        );
        Panel2Layout.setVerticalGroup(
            Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(Panel2Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(AddPassLabel, javax.swing.GroupLayout.PREFERRED_SIZE, 17, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ServiceNameLabel1)
                            .addComponent(ServiceNameTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(3, 3, 3))
                    .addGroup(javax.swing.GroupLayout.Alignment.LEADING, Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(PasswdLabel1)
                        .addComponent(AddPassField, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(SetPassButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(18, 18, Short.MAX_VALUE)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator2, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(GetPassLabel, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel2Layout.createSequentialGroup()
                            .addComponent(ServiceNameLabel2)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jLabel1))
                        .addComponent(GetPassButton, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(ServiceNameTextField2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(ChangePassLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator3, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel2)
                .addGap(1, 1, 1)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(ServiceNameLabel3)
                            .addComponent(ServiceNameTextField3, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                .addComponent(NewPasswdLabel)
                                .addComponent(jPasswordField2, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(ChangePassButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addComponent(DeletePassLabel))
                    .addComponent(jSeparator4, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addComponent(ServiceNameTextField4, javax.swing.GroupLayout.DEFAULT_SIZE, 25, Short.MAX_VALUE)
                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, Panel2Layout.createSequentialGroup()
                            .addComponent(ServiceNameLabel4)
                            .addGap(6, 6, 6)))
                    .addComponent(DeletePassButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(DeleteAccountLabel, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jSeparator6, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(UserNameLabel1)
                            .addComponent(UserNameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 25, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(Panel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(CheckSQLInjectionLabel)
                            .addComponent(CheckSQLInjectionButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(22, Short.MAX_VALUE))
                    .addGroup(Panel2Layout.createSequentialGroup()
                        .addComponent(DeleteAccountButton, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout PanelGUILayout = new javax.swing.GroupLayout(PanelGUI);
        PanelGUI.setLayout(PanelGUILayout);
        PanelGUILayout.setHorizontalGroup(
            PanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel1, javax.swing.GroupLayout.DEFAULT_SIZE, 724, Short.MAX_VALUE)
            .addGroup(PanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Panel2, javax.swing.GroupLayout.DEFAULT_SIZE, 724, Short.MAX_VALUE))
        );
        PanelGUILayout.setVerticalGroup(
            PanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Panel1, javax.swing.GroupLayout.DEFAULT_SIZE, 436, Short.MAX_VALUE)
            .addGroup(PanelGUILayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addComponent(Panel2, javax.swing.GroupLayout.DEFAULT_SIZE, 436, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelGUI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(PanelGUI, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void UserNameFieldUserNameFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserNameFieldUserNameFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UserNameFieldUserNameFieldActionPerformed
    
    //Ενέργειες που εκτελούνται όταν παταμε το κουμπι Register
    private void RegisterButtonRegisterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_RegisterButtonRegisterButtonActionPerformed

        try {
            client = new PassClient();
        } catch (RemoteException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException | NoSuchAlgorithmException | ClassNotFoundException | NoSuchProviderException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException | SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        System.out.println(UserNameField.getText());
        client.setUsername(UserNameField.getText());
    
        try {
            client.register();
        } catch (RemoteException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException | NoSuchAlgorithmException | ClassNotFoundException | NoSuchProviderException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        JOptionPane.showMessageDialog(null, "Registration completed!!!\n Welcome to our cloud manager.", "Welcome",JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_RegisterButtonRegisterButtonActionPerformed

    private void ServiceNameTextField2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServiceNameTextField2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ServiceNameTextField2ActionPerformed

    private void ServiceNameTextField1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServiceNameTextField1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ServiceNameTextField1ActionPerformed

    //Προσθηκη κωδικού
    private void SetPassButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SetPassButtonActionPerformed
        client.setService(ServiceNameTextField1.getText());
        client.setPassword(new String(AddPassField.getPassword()));
        try {
            client.addNewService();
        } catch (NoSuchAlgorithmException | IOException | ClassNotFoundException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        ServiceNameTextField1.setText("");
        AddPassField.setText("");
    }//GEN-LAST:event_SetPassButtonActionPerformed

    //Ανακτηση κωδικού
    private void GetPassButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_GetPassButtonActionPerformed
        client.setService(ServiceNameTextField2.getText());
        try {
            client.getPass();
        } catch (SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        ServiceNameTextField2.setText("");
    }//GEN-LAST:event_GetPassButtonActionPerformed

    private void ServiceNameTextField3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServiceNameTextField3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ServiceNameTextField3ActionPerformed

    private void ServiceNameTextField4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ServiceNameTextField4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ServiceNameTextField4ActionPerformed

    //Διαγραφή κωδικού
    private void DeletePassButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeletePassButtonActionPerformed
        client.setService(ServiceNameTextField4.getText());
        try {
            client.deletePassService();
        } catch (SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        ServiceNameTextField4.setText("");
    }//GEN-LAST:event_DeletePassButtonActionPerformed

    private void UserNameTextFieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_UserNameTextFieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_UserNameTextFieldActionPerformed

    //Διαγραφή λογαριασμού
    private void DeleteAccountButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_DeleteAccountButtonActionPerformed
        client.setUsername(UserNameTextField.getText());
        try {
            client.deleteAccount();
        } catch (SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        UserNameTextField.setText("");
    }//GEN-LAST:event_DeleteAccountButtonActionPerformed

    //Έλεγχος για SQL-Injection
    private void CheckSQLInjectionButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_CheckSQLInjectionButtonActionPerformed
             
        try {
            JOptionPane.showMessageDialog(null, client.checkSqlInjection(),"Πληροφορίες", JOptionPane.INFORMATION_MESSAGE);
        } catch (RemoteException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }

    }//GEN-LAST:event_CheckSQLInjectionButtonActionPerformed

    //Ενέργειες που εκτελούνται όταν παταμε το κουμπι Sign-in
    private void SignInButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_SignInButtonActionPerformed
        try {
            client = new PassClient();
        } catch (RemoteException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NotBoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchProviderException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        client.setUsername(UserNameField.getText());
        try {
            client.useManager();
        } catch (RemoteException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException | ClassNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (MalformedURLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FileNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        PanelGUI.removeAll();
        PanelGUI.repaint();
        PanelGUI.revalidate();

        PanelGUI.add(Panel2);
        PanelGUI.repaint();
        PanelGUI.revalidate();
    }//GEN-LAST:event_SignInButtonActionPerformed

    //Αλλαγή κωδικού όταν παταμε το κουμπι
    private void ChangePassButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ChangePassButtonActionPerformed
        client.setService(ServiceNameTextField3.getText());
        client.setPassword(new String(jPasswordField2.getPassword()));
        
        try {
            client.changePassword();
        } catch (SQLException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchAlgorithmException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NoSuchPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (InvalidKeyException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IllegalBlockSizeException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (BadPaddingException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(GUI.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        ServiceNameTextField3.setText("");
        jPasswordField2.setText("");
    }//GEN-LAST:event_ChangePassButtonActionPerformed

    

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPasswordField AddPassField;
    private javax.swing.JLabel AddPassLabel;
    private javax.swing.JButton ChangePassButton;
    private javax.swing.JLabel ChangePassLabel;
    private javax.swing.JButton CheckSQLInjectionButton;
    private javax.swing.JLabel CheckSQLInjectionLabel;
    private javax.swing.JButton DeleteAccountButton;
    private javax.swing.JLabel DeleteAccountLabel;
    private javax.swing.JButton DeletePassButton;
    private javax.swing.JLabel DeletePassLabel;
    private javax.swing.JButton GetPassButton;
    private javax.swing.JLabel GetPassLabel;
    private javax.swing.JLabel ImageLabel;
    private javax.swing.JLabel NewPasswdLabel;
    private javax.swing.JPanel Panel1;
    private javax.swing.JPanel Panel2;
    private javax.swing.JPanel PanelGUI;
    private javax.swing.JLabel PassManagerLabel;
    private javax.swing.JLabel PasswdLabel1;
    private javax.swing.JButton RegisterButton;
    private javax.swing.JLabel ServiceNameLabel1;
    private javax.swing.JLabel ServiceNameLabel2;
    private javax.swing.JLabel ServiceNameLabel3;
    private javax.swing.JLabel ServiceNameLabel4;
    private java.awt.TextField ServiceNameTextField1;
    private java.awt.TextField ServiceNameTextField2;
    private java.awt.TextField ServiceNameTextField3;
    private java.awt.TextField ServiceNameTextField4;
    private javax.swing.JButton SetPassButton;
    private javax.swing.JButton SignInButton;
    private java.awt.TextField UserNameField;
    private javax.swing.JLabel UserNameLabel;
    private javax.swing.JLabel UserNameLabel1;
    private java.awt.TextField UserNameTextField;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPasswordField jPasswordField2;
    private javax.swing.JSeparator jSeparator;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JSeparator jSeparator4;
    private javax.swing.JSeparator jSeparator6;
    // End of variables declaration//GEN-END:variables
}
