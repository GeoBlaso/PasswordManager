/*
Δημητρης Παναϊλιδης icsd11116
Νελλη Τσοτσου icsd11169
Γιωργος Βλασσοπουλος icsd11018
*/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.rmi.*;
import java.util.Random;
import javax.crypto.SecretKey;
import java.net.MalformedURLException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.sql.SQLException;
import java.util.Arrays;
import static java.util.Objects.hash;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.KeyGenerator;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import javax.swing.JOptionPane;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class PassClient {
    
    public  String hostname = "//localhost/PassServer";
    public  Operations look_op;
    public  BigInteger SessionKey;
    public  String username;
    public String service;
    public String password;
    
    public PassClient() throws java.net.UnknownHostException, RemoteException, NotBoundException, MalformedURLException, NoSuchAlgorithmException, FileNotFoundException, IOException, ClassNotFoundException, NoSuchProviderException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, SQLException{
        //Σύνδεση στον απομακρυσμένο υπολογιστή
        look_op =(Operations)Naming.lookup(hostname);      
    }
   
    public void setUsername(String user){
        username = user; 
    }
    
    public void setService(String serv){
        service = serv; 
    }
    
    public void setPassword(String pass){
        password = pass; 
    }
    
    //Μέθοδος για την πρώτη χρήση της εφαρμογής - εγγραφή του χρήστη
    public void register() throws java.net.UnknownHostException, RemoteException, NotBoundException, MalformedURLException, NoSuchAlgorithmException, FileNotFoundException, IOException, ClassNotFoundException, NoSuchProviderException{
            
        BigInteger Cookie_Client;
        BigInteger Cookie_Server;
        PublicKey PublicRSAkey;
        SecretKey MasterKey;
        String message;
        String cookie;
        String server;
        BigInteger xorresult1;
        BigInteger xorresult2;
        //String username;
        String path;
        
        try{         
            //Ερωτηματα 1 και 3
            //Δημιουργία cookie για τον client
            //Στέλνει το μηνυμα
            message = "hello server";           
                                 
            //Η διαδρομή με την οποία θα αποθηκεύονται το master key του κάθε χρήστη
            path = "E:\\university\\7-Semester\\Επιλογής\\Ασφάλεια Δικτύων ΙΙ\\PassManagerClient\\" + username + "\\masterkeys\\";
            File file = new File(path);
            if (!file.exists()) {
                file.mkdirs();
            }
            //Δημιουργια τυχαιου 256bit αριθμου
            Cookie_Client = new BigInteger(256, new Random());
            
            //Σύνταξη της τελικης μορφης του cookie σε απλη μορφή          
            cookie = message + "," + username + "," +Cookie_Client;
            
            //Αποστολή cookie στον server και αποθήκευση της απάντησης του server(cookie server)
            // στην μεταβλητή server           
            server = look_op.sendMessage(cookie);
            System.out.println(server);
                      
            String array[] = server.split(",");          
            //O τυχαίος 256bit του server
            Cookie_Server = new BigInteger(array[1]);            
            //Το public key του server μέσω της απομακρυσμένης μεθόδου
            PublicRSAkey = look_op.getPublicKey();
                       
            //Δημιουργία βασικού κλειδιού και η αποθήκευσή του σε αρχείο
            KeyGenerator keyGen = KeyGenerator.getInstance("AES");
            keyGen.init(256); 
            MasterKey = keyGen.generateKey();           
            
            //Δημιουργία του masterkey αρχείου
             File SecretKeyFile = new File(path + "masterkey.key");
             if (!SecretKeyFile.exists()) {
                SecretKeyFile.createNewFile();
            } 
            //Αποθήκευση του masterkey σε αρχείο
            try (ObjectOutputStream secretKeyOS = new ObjectOutputStream(new FileOutputStream(SecretKeyFile))) {
                secretKeyOS.writeObject(MasterKey);
            }
            
            //Διαβασμα του master key απο το αρχειο
            ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(path + "masterkey.key"));
            SecretKey masterKey = (SecretKey) inputStream.readObject();
            
            //Μετατρέψαμε το masterKey σε BigInteger για να κάνουμε τις πράξεις XOR
            BigInteger Mkey = new BigInteger(masterKey.getEncoded());
            System.out.println("Master key: " + Mkey);
            
            //XOR cookie_client και cookie_server
            xorresult1 = Cookie_Server.xor(Cookie_Client);           
            //XOR το παραπανω αποτελεσμα με το masterkey
            xorresult2 = xorresult1.xor(Mkey);
            
            //Encrypt xorresult2 με το public key του Server
            System.out.println("------------ Encrypt Started -------------");
      
            byte[] xorData = xorresult2.toByteArray();
            byte[] encryptData = null;
            
            try{
                Cipher cipher = Cipher.getInstance("RSA");
                cipher.init(Cipher.ENCRYPT_MODE, PublicRSAkey);
                encryptData = cipher.doFinal(xorData);
                System.out.println("------------ Encrypt End -------------");
                //Αποστολή του κρυπτογραφημένου μηνύματος στον server
                String ok = look_op.receiveKey(encryptData);
                //Τέλος ερωτημάτων 1 και 3
                //Εκτύπωση μηνύματος επιτυχής εγγραφής
                System.out.println(ok);
            }catch(NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException | RemoteException e){
            }                               
        }
        catch(java.net.UnknownHostException e) {
            System.out.println("OperationClient err: " + e);
            System.exit(1);
        }              
    }
    
    //Μέθοδος για το πρωτόκολλο οπου ο χρήστης ήδη ειναι εγγεγραμμένος
    //Εκτέλεση του ερωτήματος 6 
    public void useManager() throws RemoteException, FileNotFoundException, IOException, ClassNotFoundException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, SQLException{
        
        BigInteger Cookie_Client;
        BigInteger Cookie_Server;
        String cookie;
        String server;
        BigInteger xorresult1;
        String path;
        String pathaes;
        
        boolean flag = look_op.checkIfExist(username);
        
        if(flag == false){
            JOptionPane.showMessageDialog(null, "Δεν εισαι εγγεγραμμενος!!!", "Error",JOptionPane.ERROR_MESSAGE);
        }
        else{
 
                //Διαδρομή για την αποθήκευση των master key του κάθε χρήστη
                path = "E:\\university\\7-Semester\\Επιλογής\\Ασφάλεια Δικτύων ΙΙ\\PassManagerClient\\" + username + "\\masterkeys\\";

                //Δημιουργία του νέου τυχαίου αριθμού του client
                Cookie_Client = new BigInteger(256, new Random());
                //Μήνυμα του πελάτη
                cookie = "Hello again!" + "," + username + "," + Cookie_Client;
                //Αποστολή στον server και αποθήκευση της απάντησης του, δηλαδή το cookie server
                server = look_op.sendMessageFromRegister(cookie);      
                String array[] = server.split(","); 
                Cookie_Server = new BigInteger(array[1]);

                //Δίαβασμα του masterkey του χρήστη
                ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(path + "masterkey.key"));
                SecretKey masterKey = (SecretKey) inputStream.readObject();

                //Μετατρέψαμε το masterKey σε BigInteger για να κάνουμε τις πράξεις XOR
                BigInteger Mkey = new BigInteger(masterKey.getEncoded());
                System.out.println("Master key: " + Mkey);

                //XOR cookie_client και cookie_server
                xorresult1 = Cookie_Server.xor(Cookie_Client);           
                //XOR το παραπανω αποτελεσμα με το masterkey για την παραγωγη του session key
                SessionKey = xorresult1.xor(Mkey);

                System.out.println("Session key: " + SessionKey.toString()); 
        }
    }   
    
    public String encryptTraffic(String message) throws FileNotFoundException, IOException, ClassNotFoundException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
        
        System.out.println("Session " + SessionKey);
        //μετατροπή του αποτελέσματος XOR σε 16 bytes για να μπορούμε να κάνουμε AES
         byte [] subArray = Arrays.copyOfRange(SessionKey.toByteArray(), 0, 16);
        //Δημιουργία AES μέσω των XOR
        SecretKeySpec skeySpec = new SecretKeySpec(subArray, "AES");
        Cipher cipher2 = Cipher.getInstance("AES");
        // Αρχικοποίηση cipher2 για κρυπτογράφηση
        cipher2.init(Cipher.ENCRYPT_MODE, skeySpec);
        //sensitive informations
        //αρχικοποίηση BASE64Encoder για κωδικοποίηση του κρυπτογραφημένου text
        byte[] encryptmessage = cipher2.doFinal(message.getBytes());
        BASE64Encoder bASE64Encoder = new BASE64Encoder();
        String enStr = bASE64Encoder.encodeBuffer(encryptmessage);
        
        return enStr;
    }
    
    public String decryptData(String data) throws NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
        //Κόβουμε το SessionKey στα 16bit για την δημιουργία του κλειδιού AES
        byte[] subArray = Arrays.copyOfRange(SessionKey.toByteArray(), 0, 16);       
        SecretKeySpec skeySpec = new SecretKeySpec(subArray, "AES");
        
        Cipher cipher = Cipher.getInstance("AES");
        
        //αρχικοποίηση BASE64Decoder για κωδικοποίηση του αποκρυπτογραφημένου text
        BASE64Decoder bASE64Decoder = new BASE64Decoder();
        byte decrytByt[] = bASE64Decoder.decodeBuffer(data);

        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        
        //Αποκρυπτογράφηση του μηνύματος
        byte decrypted[] = cipher.doFinal(decrytByt);
        
        String deStr = new String(decrypted).trim();
        
        return deStr;
    }
    
    public void addNewService() throws NoSuchAlgorithmException, IOException, ClassNotFoundException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
                   
        String pathaes;       
        int hashpass;
        
        //Διαδρομή για την αποθήκευση των aes key του κάθε χρήστη
        pathaes = "E:\\university\\7-Semester\\Επιλογής\\Ασφάλεια Δικτύων ΙΙ\\PassManagerClient\\" + username + "\\aeskeys\\";
        //Διαδρομή για την αποθήκευση των hash του κάθε χρήστη
        String pathhash = "E:\\university\\7-Semester\\Επιλογής\\Ασφάλεια Δικτύων ΙΙ\\PassManagerClient\\" + username + "\\hashes\\";
        
        File file = new File(pathaes);
            if (!file.exists()) {
                file.mkdirs();
        }
         
        File file2 = new File(pathhash);
            if (!file2.exists()) {
                file2.mkdirs();
        }
            
            
        //Δημιουργία βασικού κλειδιού και η αποθήκευσή του σε αρχείο
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128); 
        SecretKey AesKey = keyGen.generateKey();           
            
        //Δημιουργία του aes αρχείου
        File SecretKeyFile = new File(pathaes + "AesKey.key");
        if (!SecretKeyFile.exists()) {
            SecretKeyFile.createNewFile();
        } 
        //Αποθήκευση του aes σε αρχείο
        try (ObjectOutputStream secretKeyOS = new ObjectOutputStream(new FileOutputStream(SecretKeyFile))) {
            secretKeyOS.writeObject(AesKey);
        }
            
        //Διαβασμα του aes key απο το αρχειο
        ObjectInputStream inputStream2 = new ObjectInputStream(new FileInputStream(pathaes + "AesKey.key"));
        SecretKey AesKeyRead = (SecretKey) inputStream2.readObject();
        
        //Δημιουργια hash plaintext του κωδικού του χρήστη
        hashpass = hash(password);      
        System.out.println(hashpass);
        
        //Δημιουργία του hash αρχείου
        File hashfile = new File(pathhash + "\\" + service + ".txt");
        if (!hashfile.exists()) {
            hashfile.createNewFile();
        } 
        //Αποθήκευση του hash σε αρχείο
        try (ObjectOutputStream hashOS = new ObjectOutputStream(new FileOutputStream(hashfile))) {
            hashOS.writeObject(hashpass);
        }
               
        Cipher desCipher;
 	// Δημιουργία cipher 
	desCipher = Cipher.getInstance("AES");
	// Αρχικοποίηση cipher για κρυπτογράφηση
	desCipher.init(Cipher.ENCRYPT_MODE, AesKeyRead);
        
        //sensitive informations
	byte[] text = password.getBytes();
        System.out.println("Pass : " + password);
	// κρυπτογράφηση  password me aes
	byte[] textEncrypted = desCipher.doFinal(text);
	System.out.println("Pass Encryted : " + textEncrypted);                   
               
        String passwordHash = Integer.toString(hashpass);
        String message = service + "," + textEncrypted.toString() + "," + passwordHash;
           
        String enStr = encryptTraffic(message);       
     
        System.out.println("Encrypt message: " + enStr);
        //Αποστολή του τελικού κρυπτογραφημένου μηνύματος στον server
        look_op.insertNewService(enStr);      
    }    
    
    public void getPass() throws RemoteException, SQLException, FileNotFoundException, IOException, ClassNotFoundException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
        String msg;
        String pwd;
        String hash;

        String pathhash = "E:\\university\\7-Semester\\Επιλογής\\Ασφάλεια Δικτύων ΙΙ\\PassManagerClient\\" + username + "\\hashes\\";
        
        String encryptMsg = username + "," + service;
        encryptMsg = encryptTraffic(encryptMsg);
        
        msg = look_op.getPassword(encryptMsg);
        
        String decryptMsg = decryptData(msg);
        
        String array[] = decryptMsg.split(",");
        pwd = array[0];
        hash = array[1];
        
        ObjectInputStream hashstream = new ObjectInputStream(new FileInputStream(pathhash + "\\" + service + ".txt"));
        int readhash = (int) hashstream.readObject();
        
        if(Integer.valueOf(hash) == readhash){
            System.out.println("Server is trusted!!!");
            System.out.println("Your Password is: " + pwd);
            JOptionPane.showMessageDialog(null,"Server is trusted!!!\n  Your Password is: " + pwd,"Κωδικός",JOptionPane.INFORMATION_MESSAGE);
        }
        else{
            System.out.println("Server make suspicious process!!!");
        }       
    }
    
    public void changePassword() throws RemoteException, SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, FileNotFoundException, ClassNotFoundException{
       
        //Διαδρομή για την αποθήκευση των aes key του κάθε χρήστη
        String pathaes = "E:\\university\\7-Semester\\Επιλογής\\Ασφάλεια Δικτύων ΙΙ\\PassManagerClient\\" + username + "\\aeskeys\\";
        
         //Διαβασμα του aes key απο το αρχειο
        ObjectInputStream inputStream2 = new ObjectInputStream(new FileInputStream(pathaes + "AesKey.key"));
        SecretKey AesKeyRead = (SecretKey) inputStream2.readObject();
        
        Cipher desCipher;
 	// Δημιουργία cipher 
	desCipher = Cipher.getInstance("AES");
	// Αρχικοποίηση cipher για κρυπτογράφηση
	desCipher.init(Cipher.ENCRYPT_MODE, AesKeyRead);
        
        //sensitive informations
	byte[] text = password.getBytes();
	// κρυπτογράφηση  password me aes
	byte[] textEncrypted = desCipher.doFinal(text);
        
        String encryptMsg = service + "," + textEncrypted.toString();
        encryptMsg = encryptTraffic(encryptMsg);
        
        look_op.changePassword(encryptMsg);
        
        JOptionPane.showMessageDialog(null, "Password changed!!! ", "Κωδικός",JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void deletePassService() throws RemoteException, SQLException, IOException, FileNotFoundException, ClassNotFoundException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{

        String encryptMsg = service + ",";
        encryptMsg = encryptTraffic(encryptMsg);
        look_op.deletePassService(encryptMsg);
        JOptionPane.showMessageDialog(null, "Password deleted from " + service + "!!!", "Κωδικός",JOptionPane.INFORMATION_MESSAGE);
    }
    
    public void deleteAccount() throws RemoteException, SQLException, IOException, FileNotFoundException, ClassNotFoundException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
      
        String encryptMsg = username + ",";
        encryptMsg = encryptTraffic(encryptMsg);
        
        look_op.deleteAccount(encryptMsg);
        JOptionPane.showMessageDialog(null, "Account " + username + " deleted from our server.\n Good BYE!!!", "Κωδικός",JOptionPane.INFORMATION_MESSAGE);
    }
    
    public String checkSqlInjection() throws RemoteException, SQLException{
        String msg;
        boolean flag = look_op.checkSqlInjection();
        
        if(flag == false){
            msg = "You are safe!!!";
        }
        else{
            msg = "WARNING: Sql injection!!!!!!!";
        }
        return msg;
    } 
}
