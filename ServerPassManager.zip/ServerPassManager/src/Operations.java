/*
Δημητρης Παναϊλιδης icsd11116
Νελλη Τσοτσου icsd11169
Γιωργος Βλασσοπουλος icsd11018
*/

import java.io.FileNotFoundException;
import java.io.IOException;
import java.rmi.*;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PublicKey;
import java.sql.SQLException;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public interface Operations extends Remote{

   //Ανάκτηση του δημόσιου κλειδιού
   public PublicKey getPublicKey() throws RemoteException;
   
   //Μέθοδος όπου ο πελάτης στέλνει το μήνυμα του με τα απαραίτητα στοιχεία
   //και στην συνέχεια ο server επιστρέφει τα δικά του
   public String sendMessage(String clientMessage) throws RemoteException, NoSuchAlgorithmException, NoSuchProviderException, FileNotFoundException, IOException;
   
   //Μέθοδος για το πρωτόκολλο για τους ηδη εγγεγραμμενους χρηστες
   public String sendMessageFromRegister(String registerusermessage) throws RemoteException;
   
   //Μέθοδος που λαμβάνει το κρυπτογραφημένο κλειδί και ο server
   //το αποκωδικοποιεί για την ανάκτηση του masterkey
   public String receiveKey(byte[] encryptData) throws RemoteException;
   
   //Κρυπτογράφηση του traffic
   public String encryptTraffic(String message) throws FileNotFoundException, IOException, ClassNotFoundException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException;
   
   //Αποκρυπτογράφηση του traffic
   public String decryptData(String data) throws NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException;
   
   //Μέθοδος για εισαγωγή κωδικού σε μια νέα υπηρεσία
   public void insertNewService(String message) throws RemoteException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException;
 
   //Μέθοδος με την οποία επιστρέφεται στον χρήστη ο κωδικός πρόσβασης της υπηρεσίας 
    //αλλα και του hash του κωδικού για να γίνει η επαλήθευση της ακεραιότητας του
   public String getPassword(String message) throws RemoteException, SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException;
   
   //Μέθοδος για την αλλαγή κωδικού μιας υπηρεσίας
   public void changePassword(String message) throws RemoteException, SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException;
   
   //Μέθοδος για την διαγραφεί απο την βάση ένας κωδικός υπηρεσίας
   public void deletePassService(String message) throws RemoteException, SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException;
   
   //Μέθοδος για την διαγραφεί λογαριασμού
   public void deleteAccount(String message) throws RemoteException, SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException;
   
   //Και μία βασική μέθοδος για τον έλεγχο ευπάθεια σε sql injection
   public boolean checkSqlInjection() throws RemoteException, SQLException;
   
   //Ελεγχος εαν ενας χρήστης υπάρχει
   public boolean checkIfExist(String username) throws RemoteException, SQLException;
}
