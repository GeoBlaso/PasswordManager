/*
Δημητρης Παναϊλιδης icsd11116
Νελλη Τσοτσου icsd11169
Γιωργος Βλασσοπουλος icsd11018
*/

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.math.BigInteger;
import java.rmi.*;
import java.rmi.server.*;
import java.security.InvalidKeyException;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.NoSuchProviderException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.util.Random;
import javax.crypto.Cipher;
import java.sql.*;
import java.util.Arrays;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class PassServer extends UnicastRemoteObject implements Operations{

    private BigInteger Cookie_Server;
    private BigInteger Cookie_Client;
    private PrivateKey PrivateRSAkey; 
    private PublicKey PublicRSAkey;
    private Statement stat;
    private String username;
    private Connection conn;
    private String path;
    private BigInteger SessionKey;
    
    public PassServer () throws RemoteException, NoSuchAlgorithmException, NoSuchProviderException, FileNotFoundException, IOException {
        
        super();  
        
        try {
            //Σύνδεση στην βάση δεδομένων
            Class.forName("org.sqlite.JDBC");
            conn = DriverManager.getConnection("jdbc:sqlite:clients.db");
            stat = conn.createStatement();
            System.out.println ("Database connection established");         
            
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(PassServer.class.getName()).log(Level.SEVERE, null, ex);
        }   
    }
    
    @Override
    public PublicKey getPublicKey(){
        return PublicRSAkey;
    }
    
    //Εδώ γίνονται τα βήματα των ερωτημάτος 2
    @Override
    public String sendMessage(String clientMessage) throws RemoteException, NoSuchAlgorithmException, NoSuchProviderException, FileNotFoundException, IOException {
        
        //Παίρνουμε το μύνημα που έστειλε ο client και αποθηκεύουμε το Cookie_Client
        String array[] = clientMessage.split(",");
        System.out.println(clientMessage);
        //Το όνομα του χρήστη
        username = array[1];
        //Η διαδρομή με την οποία θα αποθηκεύονται τα κλειδία του κάθε χρήστη
        path = "E:\\university\\7-Semester\\Επιλογής\\Ασφάλεια Δικτύων ΙΙ\\ServerPassManager\\" + username + "\\keys";
        File file = new File(path);
            if (!file.exists()) {
                file.mkdirs();
        }
            
        //Δήμιουργία RSA κλειδιών και η αποθήκευσή τους σε αρχεία
        KeyPairGenerator keyGen = KeyPairGenerator.getInstance("RSA");
        SecureRandom random = SecureRandom.getInstance("SHA1PRNG", "SUN");
        keyGen.initialize(1024, random);      
        KeyPair pair = keyGen.generateKeyPair(); 
        
        //Δημιουργία του Private Key αρχείου
        File privateKeyFile = new File(path + "\\private.key");
        if (!privateKeyFile.exists()) {
            privateKeyFile.createNewFile();
        }
              
        //Δημιουργία του Public Key αρχείου
        File publicKeyFile = new File(path + "\\public.key");
        if (!publicKeyFile.exists()) {
            publicKeyFile.createNewFile();
        }
        //Εγγραφή του private key στο αρχείο
        ObjectOutputStream privateKeyOS = new ObjectOutputStream(new FileOutputStream(privateKeyFile));
        privateKeyOS.writeObject(pair.getPrivate());
        //Εγγραφή του public key στο αρχείο
        ObjectOutputStream publicKeyOS = new ObjectOutputStream(new FileOutputStream(publicKeyFile));
        publicKeyOS.writeObject(pair.getPublic());
        
        //Άνοιγμα των stream για την ανάγνωση των κλειδιών
        ObjectInputStream inputStream = new ObjectInputStream(new FileInputStream(path + "\\public.key"));
        ObjectInputStream inputStream2 = new ObjectInputStream(new FileInputStream(path + "\\private.key"));
         
        try {
            //Εισαγωγή των κλειδιών στην αντιστοιχη μεταβλητή για μελλοντική χρήση
            PublicRSAkey = (PublicKey) inputStream.readObject();
            PrivateRSAkey = (PrivateKey) inputStream2.readObject();
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PassServer.class.getName()).log(Level.SEVERE, null, ex);
        }
                   
        //Αποθήκευση του τυχαίου αριθμου του client για μελλοντική χρήση
        Cookie_Client = new BigInteger(array[2]);
        
        //Δημιουργούμε έναν Cookie_Server
        Cookie_Server= new BigInteger(256, new Random());
        //Στέλνουμε στον πελάτη το μήνυμα και τον τυχαίο αριθμό του Server
        //το Public key θα το πάρει ο πελάτη καλώντας την απομακρυσμένη
        //μέθοδο του server getPublicKey().
        return "Hello Client,"+ Cookie_Server;       
    }

    //Εδώ πραγματοποιείται το ερώτημα 4
    //Ο server αποκρυπτογραφή αυτα που του έστειλε ο πελάτης
    @Override
    public String receiveKey(byte[] encryptData) throws RemoteException {
        
        byte[] decryptData = null;
        System.out.println("----------------- Decryption Started--------------");
        try{
            Cipher cipher = Cipher.getInstance("RSA");
            //Αποκρυπτογραφηση με το private key
            cipher.init(Cipher.DECRYPT_MODE, PrivateRSAkey);
            decryptData = cipher.doFinal(encryptData);          
        }catch(NoSuchAlgorithmException | NoSuchPaddingException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e){
        }
        System.out.println("----------------- Decryption End--------------");
        
        BigInteger decodeData = new BigInteger(decryptData);
        
        //Εκτελεση XOR με το cookie του server και τα αποκρυπτογραφημενα δεδομενα(decodeData)
        BigInteger xorresult = Cookie_Server.xor(decodeData);
        
        //Και το αποτελεσμα του πρωτου XOR το κανουμε XOR με το cookie του client
        //και στο τέλος παίρνουμε το master key.
        BigInteger masterkey = xorresult.xor(Cookie_Client);
        System.out.println("Master key: " + masterkey);
        masterkey.toString();
        
        try {
            stat.executeUpdate("CREATE TABLE clients (username varchar(50), masterkey varchar(70));");
        } catch (SQLException ex) {
            Logger.getLogger(PassServer.class.getName()).log(Level.SEVERE, null, ex);
        }

       
        //Ενημερωση της βασης CLIENTS το username, masterkey
        String message = "INSERT INTO clients (username, masterkey) VALUES ('" + 
                username + "','" + masterkey + "')";
        
        //Δημιουργία πίνακα με το ονομα του χρηστη και τα πέδια service, password, hash
        try {
            stat.executeUpdate(message);
            String msg = "CREATE TABLE " + username + " (service varchar(22), password varchar(22), hash varchar(40));";
            stat.executeUpdate(msg);           
        } catch (SQLException ex) {
            Logger.getLogger(PassServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Επιστρέφει μήνυμα επιτυχως σύνδεσης στην υπηρεσία
        return "welcome to our Cloud Password Manager " + username + " !!!";                 
    }
    
    //Μέθοδος για το πρωτόκολλο οπου ο χρήστης ήδη ειναι εγγεγραμμένος
    //Εκτέλεση του ερωτήματος 7
    @Override
    public String sendMessageFromRegister(String registerusermessage){
        //Παίρνουμε το μύνημα που έστειλε ο client και αποθηκεύουμε το Cookie_Client
        String array[] = registerusermessage.split(",");
        System.out.println(registerusermessage);
        
        this.username = array[1];
        Cookie_Client = new BigInteger(array[2]);
        
        //Δημιουργούμε έναν Cookie_Server
        Cookie_Server= new BigInteger(256, new Random());
        
        ResultSet records = null;
        String masterkey = null;
        BigInteger mkey = null;
        
        //Εδώ εκτελείται η εισαγωγή του masterkey του user απο την βάση
        try{
            records = stat.executeQuery("SELECT masterkey FROM clients WHERE username='" + username + "';");           
            while(records.next()){
               masterkey = records.getString("masterkey");
               mkey = new BigInteger(masterkey);
            }             
        }catch(SQLException ex){
            Logger.getLogger(PassServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //Παρακάτω γίνονται οι διαδικασίες XOR για την δημιουργία του SessionKey
        BigInteger xorresult1 = Cookie_Server.xor(Cookie_Client);
        SessionKey = xorresult1.xor(mkey);
        System.out.println("Master key: " + masterkey);
        System.out.println("Session key: " + SessionKey);
        
        return "Hello again Client,"+ Cookie_Server;    
    }
    
    @Override
    public String encryptTraffic(String message) throws FileNotFoundException, IOException, ClassNotFoundException, NoSuchAlgorithmException, NoSuchPaddingException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
      
        //μετατροπή του αποτελέσματος XOR σε 16 bytes για να μπορούμε να κάνουμε AES
         byte [] subArray = Arrays.copyOfRange(SessionKey.toByteArray(), 0, 16);
        //Δημιουργία AES μέσω των XOR
        SecretKeySpec skeySpec = new SecretKeySpec(subArray, "AES");
        Cipher cipher2 = Cipher.getInstance("AES");
        // Αρχικοποίηση cipher2 για κρυπτογράφηση
        cipher2.init(Cipher.ENCRYPT_MODE, skeySpec);
        //sensitive informations
        //αρχικοποίηση BASE64Encoder για κωδικοποίηση του κρυπτογραφημένου text
        byte[] encryptmessage = cipher2.doFinal(message.getBytes());
        
        BASE64Encoder bASE64Encoder = new BASE64Encoder();
        String enStr = bASE64Encoder.encodeBuffer(encryptmessage);
        String deStr = new String(encryptmessage).trim();
        
        return enStr;
    }
    
    @Override
    public String decryptData(String data) throws NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
        //Κόβουμε το SessionKey στα 16bit για την δημιουργία του κλειδιού AES
        byte[] subArray = Arrays.copyOfRange(SessionKey.toByteArray(), 0, 16);       
        SecretKeySpec skeySpec = new SecretKeySpec(subArray, "AES");
        
        Cipher cipher = Cipher.getInstance("AES");
        
        //αρχικοποίηση BASE64Decoder για κωδικοποίηση του αποκρυπτογραφημένου text
        BASE64Decoder bASE64Decoder = new BASE64Decoder();
        byte decrytByt[] = bASE64Decoder.decodeBuffer(data);

        cipher.init(Cipher.DECRYPT_MODE, skeySpec);
        
        //Αποκρυπτογράφηση του μηνύματος
        byte decrypted[] = cipher.doFinal(decrytByt);
        
        String deStr = new String(decrypted).trim();
        
        return deStr;
    }
    
    //Μέθοδος με την οποία ο server παίρνει το κρυπτογραφημένο μήνυμα απο τον
    //πελάτη και εισάγει τα στοιχεία αφου τα αποκρυπτογραφήσει στην βάση
    @Override
    public void insertNewService(String message) throws NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
     
        System.out.println("encrypt_message : " + message);      
               
        String deStr = decryptData(message);
        System.out.println("decrypted_message : " + deStr);
        
        //Αποθήκευση των στοιχειών στις κατάλληλες μεταβλητές
        String array[] = deStr.split(",");
        String serv = array[0];
        String AESPass = array[1];
        String hashed = array[2];
        
        String insert = "INSERT INTO " + username + "(service,password,hash) VALUES ('"
                + serv + "','" + AESPass + "','" + hashed + "')";
        try {
            //Εισαγωγή στον πίνακα με το ονομα του χρηστη  τα πέδια service, password, hash
            stat.executeUpdate(insert);
        } catch (SQLException ex) {
            Logger.getLogger(PassServer.class.getName()).log(Level.SEVERE, null, ex);
        }    
    }
   
    //Μέθοδος με την οποία επιστρέφεται στον χρήστη ο κωδικός πρόσβασης της υπηρεσίας 
    //αλλα και του hash του κωδικού για να γίνει η επαλήθευση της ακεραιότητας του 
    @Override
    public String getPassword(String message) throws SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException, FileNotFoundException{
        ResultSet records;
        String pwd = null;
        String hash = null;
        String msg;
        
        String deStr = decryptData(message);
        
        //Αποθήκευση των στοιχειών στις κατάλληλες μεταβλητές
        String array[] = deStr.split(",");
        String user = array[0];
        String serv = array[1];
 
        records = stat.executeQuery("SELECT password, hash FROM " + user + " WHERE service='" + serv + "';");
        while(records.next()){
            pwd = records.getString("password");
            hash = records.getString("hash");
        }
        
        msg = pwd + "," + hash;
        try {
            msg = encryptTraffic(msg);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(PassServer.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return msg;
    }
    
    //Μέθοδος για την αλλαγή κωδικού μιας υπηρεσίας
    @Override
    public void changePassword(String message) throws SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
        ResultSet records;
        
        String deStr = decryptData(message);
         
        //Αποθήκευση των στοιχειών στις κατάλληλες μεταβλητές
        String array[] = deStr.split(",");
        String service = array[0];
        String password = array[1];
        
        String update = "UPDATE " + username + " set PASSWORD='" + password +"' WHERE service='" + service + "';";
        stat.executeUpdate(update);         
    }
    
    //Μέθοδος για την διαγραφεί απο την βάση ένας κωδικός υπηρεσίας
    @Override
    public void deletePassService(String message) throws SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
        
        String deStr = decryptData(message);
        
        //Αποθήκευση των στοιχειών στις κατάλληλες μεταβλητές
        String array[] = deStr.split(",");
        String service = array[0];
        
        String delete = "DELETE FROM " + username + " WHERE service='" + service +"';";
        stat.executeUpdate(delete);       
    }
    
    //Μέθοδος για την διαγραφεί λογαριασμού
    @Override
    public void deleteAccount(String message) throws SQLException, NoSuchAlgorithmException, NoSuchPaddingException, IOException, InvalidKeyException, IllegalBlockSizeException, BadPaddingException{
        
        String deStr = decryptData(message);
       
        //Αποθήκευση των στοιχειών στις κατάλληλες μεταβλητές
        String array[] = deStr.split(",");
        String user = array[0];
        
        String drop = "DROP TABLE if exists " + user + ";";
        stat.executeUpdate(drop);
        String delete = "DELETE FROM CLIENTS WHERE username='" + user + "';";
        stat.executeUpdate(delete);
            
    }
    
    //Και μία βασική μέθοδος για τον έλεγχο ευπάθεια σε sql injection
    
    @Override
    public boolean checkSqlInjection() throws SQLException{
        String pwd = null;
        String serv = "Nothing' OR '1'='1"; 
        boolean flag = false;
        
        ResultSet records = stat.executeQuery("SELECT password, hash FROM " + username + " WHERE service='" + serv + "';");
        while(records.next()){
            pwd = records.getString("password");
        }
        
        if(pwd == null){
            System.out.println("You are safe!!!");
        }
        else{
            System.out.println("WARNING: Sql injection!!!!!!!");
            flag = true;
        }
        return flag;
    }
    
    //Έλεγχος αν ένας χρήστης υπάρχει ώστε να ελέγχεται αν παέι να κάνει signin 
    //χωρίς να έχει εγγραφεί
    @Override
    public boolean checkIfExist(String username) throws SQLException{
        boolean flag;
        String user = null;
        
        ResultSet records = stat.executeQuery("SELECT username FROM clients WHERE username='" + username + "';");
        while(records.next()){
            user = records.getString("username");
        }
        
        if(user == null){
            flag = false;
        }
        else{
            flag = true;
        }
        return flag;
    }
       
    public static void main(String[] args) {
        try {
            // RMISecurityManager security = new RMISecurityManager();
            // System.setSecurityManager(security);
            PassServer server=new PassServer ();
            Naming.rebind("//localhost/PassServer", server);
        }
        catch (NoSuchAlgorithmException | NoSuchProviderException | IOException e) {
            System.out.println("OperationServer err: " + e);
            System.exit(1);
        }
    }
    
}
